#import <Foundation/Foundation.h>
@interface PodsDummy_firebase_auth : NSObject
@end
@implementation PodsDummy_firebase_auth
@end
