#import <Foundation/Foundation.h>
@interface PodsDummy_PromisesObjC : NSObject
@end
@implementation PodsDummy_PromisesObjC
@end
