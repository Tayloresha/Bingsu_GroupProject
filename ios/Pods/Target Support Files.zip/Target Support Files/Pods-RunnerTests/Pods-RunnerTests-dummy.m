#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_RunnerTests : NSObject
@end
@implementation PodsDummy_Pods_RunnerTests
@end
