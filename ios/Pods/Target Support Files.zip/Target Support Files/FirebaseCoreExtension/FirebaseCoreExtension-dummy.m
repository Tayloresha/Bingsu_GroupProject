#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseCoreExtension : NSObject
@end
@implementation PodsDummy_FirebaseCoreExtension
@end
