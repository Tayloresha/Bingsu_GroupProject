#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseFirestore : NSObject
@end
@implementation PodsDummy_FirebaseFirestore
@end
