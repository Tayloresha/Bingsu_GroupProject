#import <Foundation/Foundation.h>
@interface PodsDummy_firebase_core : NSObject
@end
@implementation PodsDummy_firebase_core
@end
