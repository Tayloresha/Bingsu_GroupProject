#import <Foundation/Foundation.h>
@interface PodsDummy_cloud_firestore : NSObject
@end
@implementation PodsDummy_cloud_firestore
@end
