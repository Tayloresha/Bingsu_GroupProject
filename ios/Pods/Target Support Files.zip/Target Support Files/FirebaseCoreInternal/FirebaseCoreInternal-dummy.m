#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseCoreInternal : NSObject
@end
@implementation PodsDummy_FirebaseCoreInternal
@end
