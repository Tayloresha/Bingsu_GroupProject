#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseFirestoreInternal : NSObject
@end
@implementation PodsDummy_FirebaseFirestoreInternal
@end
