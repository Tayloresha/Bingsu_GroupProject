#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseSharedSwift : NSObject
@end
@implementation PodsDummy_FirebaseSharedSwift
@end
