#import <Foundation/Foundation.h>
@interface PodsDummy_flutter_local_notifications : NSObject
@end
@implementation PodsDummy_flutter_local_notifications
@end
